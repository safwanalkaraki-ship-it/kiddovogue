
export function Card({ children, className }) {
  return <div className={`rounded border ${className}`}>{children}</div>;
}
export function CardContent({ children, className }) {
  return <div className={className}>{children}</div>;
}
