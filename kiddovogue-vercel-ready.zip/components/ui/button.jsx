
export function Button({ children, className, onClick, size, variant }) {
  return (
    <button onClick={onClick} className={`px-4 py-2 rounded ${className}`}>
      {children}
    </button>
  );
}
