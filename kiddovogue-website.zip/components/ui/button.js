export function Button({ children, className = "", ...props }) {
  return (
    <button
      className={`rounded-xl px-4 py-2 text-sm font-semibold shadow ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
